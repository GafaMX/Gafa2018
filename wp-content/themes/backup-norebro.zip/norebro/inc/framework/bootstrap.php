<?php

	// include Norebro components
	include_once get_template_directory() . '/inc/framework/Components/Settings.php';
	include_once get_template_directory() . '/inc/framework/Components/Layout.php';
	include_once get_template_directory() . '/inc/framework/Components/Helper.php';
	include_once get_template_directory() . '/inc/framework/Components/ObjectParser.php';